<footer>
<div class="footerLeft">
            <div class="footerMenu">
                <h1 class="fMenuTitle">à propos</h1>
                <ul class="fList">
                    <li class="fListItem">Company</li>
                    <li class="fListItem">Contact</li>
                    <li class="fListItem">Careers</li>
                    <li class="fListItem">Affiliates</li>
                    <li class="fListItem">Stores</li>
                </ul>
            </div>
            <div class="footerMenu">
                <h1 class="fMenuTitle">liens utile</h1>
                <ul class="fList">
                    <li class="fListItem">Support</li>
                    <li class="fListItem">Refund</li>
                    <li class="fListItem">FAQ</li>
                    <li class="fListItem">Feedback</li>
                    <li class="fListItem">Stories</li>
                </ul>
            </div>
            <div class="footerMenu">
                <h1 class="fMenuTitle">articles</h1>
                <ul class="fList">
                    <li class="fListItem">Air Force</li>
                    <li class="fListItem">Air Jordan</li>
                    <li class="fListItem">Blazer</li>
                    <li class="fListItem">Crater</li>
                    <li class="fListItem">Hippie</li>
                    <li class="fListItem"><a href="catalogue.php">PLUS <span>+</span></a></li>
                </ul>
            </div>
        </div>
        <div class="footerRight">
            <div class="footerRightMenu">
                <h1 class="fMenuTitle">s'insrire à la newsletter</h1>
                <div class="fMail">
                    <input type="text" placeholder="your@email.com" class="fInput">
                    <button class="fButton">envoyer!</button>
                </div>
            </div>
            <div class="footerRightMenu">
                <h1 class="fMenuTitle">suivez moi</h1>
                <div class="fIcons">
                    <img src="./images/facebook.png" alt="" class="fIcon">
                    <img src="./images/twitter.png" alt="" class="fIcon">
                    <img src="./images/instagram.png" alt="" class="fIcon">
                    <img src="./images/whatsapp.png" alt="" class="fIcon">
                </div>
            </div>
            <div class="footerRightMenu">
                <span class="copyright">&copy; Copyright © 2024 Dreamce store | Tous droits réservés | Conçu et développé par Waleu Brice</span>
            </div>
        </div>
</footer>
</body>

</html>